

	import java.awt.BorderLayout;
	 
	import javax.swing.ImageIcon;
	import javax.swing.JFrame;
	import javax.swing.JLabel;
	import javax.swing.SwingUtilities;
	 
	public class TestImage extends JFrame {
		private static final long serialVersionUID = 1L;
	 
		public TestImage() {
			super("TestImage");
	setDefaultCloseOperation(EXIT_ON_CLOSE);
	 
			getContentPane().add(new JLabel(new ImageIcon(ClassLoader.getSystemResource("loading.gif"))), BorderLayout.SOUTH);
	 
		}
	 
		public static void main(String[] args) {
			SwingUtilities.invokeLater(new Runnable() {
				@Override
				public void run() {
					JFrame frame = new TestImage();
					frame.setSize(320, 240);
					frame.setLocationRelativeTo(null);
					frame.setVisible(true);
	}
			});
		}
	}


