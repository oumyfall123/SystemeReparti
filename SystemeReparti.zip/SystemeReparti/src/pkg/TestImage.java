package pkg;
 
import java.awt.BorderLayout;
 
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.SwingUtilities;
 
public class TestImage extends JFrame implements MouseMotionListener{
	private static final long serialVersionUID = 1L;
 
	public TestImage() {
		super("TestImage");
setDefaultCloseOperation(EXIT_ON_CLOSE);
 		addMouseMotionListener(this);
		getContentPane().add(new JLabel(new ImageIcon(ClassLoader.getSystemResource("pkg/img/loading.GIF"))), BorderLayout.SOUTH);
 
	}
 
	public static void main(String[] args) {
		SwingUtilities.invokeLater(new Runnable() {
			@Override
			public void run() {
				JFrame frame = new TestImage();
				frame.setSize(320, 240);
				frame.setLocationRelativeTo(null);
				frame.setVisible(true);
}
		});
	}


	@Override
	public void mouseDragged(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseMoved(MouseEvent e) {
		// TODO Auto-generated method stub
		System.out.println(e.getX()+" "+e.getY());
	}
}