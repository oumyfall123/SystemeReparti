package pkg;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class accueil extends JFrame{
	public accueil(){
		super("Bienvenue dans notre plateforme de dialogue");
		this.setSize(200, 200);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setLocationRelativeTo(null);
		JPanel pan = new JPanel();
		this.setContentPane(pan);
		pan.setBackground(Color.black);
		GridLayout gl=new GridLayout(2,1);
		pan.setLayout(gl);
		gl.setHgap(10);
		gl.setVgap(10); 
		pan.add(new JButton("S'inscrire"));
		pan.add(new JButton("S'identifier"));
		
		this.setBounds(250, 250,350,150);
		
		this.setVisible(true);
	
		
	}

	public static void main(String[] args){
		new accueil();
	}
}
