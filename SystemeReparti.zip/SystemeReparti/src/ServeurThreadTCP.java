import java.net.*; 
import java.io.*;
public class ServeurThreadTCP extends Thread {
	final static int port = 9632;
	private Socket chaussette;
	public static void main(String[] args) {
		try {
			ServerSocket socketServeur = new ServerSocket(port);
			System.out.println("Lancement du serveur");
			while (true) {
				Socket socketClient = socketServeur.accept();
				TestServeurThreadTCP toto = new TestServeurThreadTCP(socketClient);
				toto.start(); // démarrer le thread et
				//exécuter la méthode run()
			}
		} catch (Exception e) {
			e.printStackTrace();
			}
	}
}


