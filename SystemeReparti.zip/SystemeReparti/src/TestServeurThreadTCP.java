import java.net.*; 
import java.io.*;
public class TestServeurThreadTCP extends Thread {
	final static int port = 9632;
	private Socket chaussette;
	
	public TestServeurThreadTCP(Socket chaussette) {
		this.chaussette = chaussette;
	}

	public void run() {
		// Spécification du code à exécuter dans le processusléger
		traitements();
	}

	public void traitements() {
		try {
			String message = "";
			System.out.println("Connexion avec le client : " +
			chaussette.getInetAddress());
			BufferedReader in = new BufferedReader(new
			InputStreamReader(chaussette.getInputStream()));
			PrintStream out = new PrintStream(chaussette.getOutputStream());
			message = in.readLine();
			out.println("Bonjour " + message);
			chaussette.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	
	public static void main(String[] args) {
		try {
			ServerSocket socketServeur = new ServerSocket(port);
			System.out.println("Lancement du serveur");
			while (true) {
				Socket socketClient = socketServeur.accept();
				TestServeurThreadTCP toto = new
				TestServeurThreadTCP(socketClient);
				toto.start(); // démarrer le thread et
				//exécuter la méthode run()
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}


