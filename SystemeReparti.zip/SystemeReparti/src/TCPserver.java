import java.io.*;
import java.net.*;
import java.util.Scanner;
public class TCPserver {

	public static void main(String [] args) throws Exception{
		String clientsentence;
		String capitalizedsentence;
		ServerSocket welcomesocket=new ServerSocket(6789);
		while(true)
		{
			Socket connexionsocket=welcomesocket.accept();
			BufferedReader inFromUser = new BufferedReader(new InputStreamReader(connexionsocket.getInputStream()));
			DataOutputStream outToClient = new DataOutputStream(connexionsocket.getOutputStream());
			clientsentence=inFromUser.readLine();
			capitalizedsentence=clientsentence.toUpperCase()+'\n';
			outToClient.writeBytes(capitalizedsentence+" \n");
			
		}
		
	}

}
