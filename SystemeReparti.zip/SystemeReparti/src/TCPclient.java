import java.io.*;
import java.net.*;
import java.util.Scanner;
public class TCPclient {
	public static void main(String [] args) throws Exception{
		String sentence;
		String modifiedsentence;
		System.out.println("Donner votre phrase\n");
		BufferedReader inFromUser = new BufferedReader(new InputStreamReader(System.in));
		//Scanner var=new Scanner(System.in);
		//int a=var.nextInt();
		Socket clientSocket=new Socket("hostname",6789);
		DataOutputStream outToServer = new DataOutputStream(clientSocket.getOutputStream());
		BufferedReader inFromServer = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
		sentence=inFromUser.readLine();
		outToServer.writeBytes(sentence+" \n");
		modifiedsentence=inFromServer.readLine();
		System.out.println("IN FROM SERVER"+modifiedsentence);
		clientSocket.close();
	}

}
