import java.net.*;
import java.io.*;

/** Classe d’un client TCP pour le protocole Echo (RFC 862). */
public class Client {
	public static void main(String args[]) throws Exception {
	/** Port réservé pour le protocole Echo */
		final int ECHO_PORT = 7890;
		/** envoie d’un message vers 1 serveur Echo et reçoit la réponse*/
		if (args.length !=2) {
			System.err.println("Usage; + <serveur> <msg>"); System.exit(1);
		}
			Socket s = new Socket(args[0], ECHO_PORT);
			System.out.println("connexion établie entre :") ;
			System.out.println("\t"+ s.getInetAddress() +":"+ s.getPort());
			System.out.println("et \t"+ s.getLocalAddress() +":"+ s.getLocalPort());

			System.out.println("Taille des tampons :");
			System.out.println("\tEmission : "+s.getSendBufferSize());
			System.out.println("\tRéception :"+s.getReceiveBufferSize());
// Récupération d’un flot en écriture sur la connexion
			PrintStream out = new PrintStream(s.getOutputStream());
			out.println(args[1]); out.flush();
//Récupération d’un flot en lecture sur la connexion
			InputStreamReader tmp = new
			InputStreamReader(s.getInputStream());
			LineNumberReader in = new LineNumberReader(tmp);
// Affichage de ce qui est lu sur la connexion
			System.out.println(in.readLine());	
			s.close(); 
		
	}
}

